create database actividades
use actividades

CREATE TABLE TipoActividad (
    idTipoActividad INT AUTO_INCREMENT,
    descripcion VARCHAR(100) NOT NULL,
    nombreactividad VARCHAR(100) NOT NULL,
    estatus TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (idTipoActividad)
);

-- Crear la tabla DetalleEvaluacion
CREATE TABLE DetalleEvaluacion (
    idDetalleEvaluacion INT AUTO_INCREMENT,
    calificacion VARCHAR(50) NOT NULL,
    criterio VARCHAR(100) NOT NULL,
    estatus TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (idDetalleEvaluacion)
);

-- Crear la tabla DetalleActividad
CREATE TABLE DetalleActividad (
    idDetalleActividad INT AUTO_INCREMENT,
    descripcion VARCHAR(100) NOT NULL,
    idDetalleEvaluacion INT,
    idActividadComplementaria INT,
    estatus TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (idDetalleActividad)
);

-- Crear la tabla Empleado
CREATE TABLE Empleado (
    idEmpleado INT AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    apellidoPaterno VARCHAR(50) NOT NULL,
    apellidoMaterno VARCHAR(50) NOT NULL,
    genero VARCHAR(50) NOT NULL,
    telefono CHAR(10) NOT NULL,
    correo VARCHAR(50) NOT NULL,
    direccion VARCHAR(100) NOT NULL,
    seguroSocial CHAR(11) NOT NULL,
    fechaContratacion DATE NOT NULL,
    estatus TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (idEmpleado)
);

-- Crear la tabla Estudiante
CREATE TABLE Estudiante (
    idEstudiante INT AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    apellidoPaterno VARCHAR(50) NOT NULL,
    apellidoMaterno VARCHAR(50) NOT NULL,
    fechaNacimiento DATE NOT NULL,
    curp CHAR(18) NOT NULL,
    telefono CHAR(10) NOT NULL,
    rfc CHAR(13) NOT NULL,
    seguroSocial CHAR(11) NOT NULL,
    estatus TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (idEstudiante)
);

-- Crear la tabla ActividadComplementaria
CREATE TABLE ActividadComplementaria (
    idActividadComplementaria INT AUTO_INCREMENT,
    nombreactividad VARCHAR(50) NOT NULL,
    estatus TINYINT(1) NOT NULL DEFAULT 1,
    idEstudiante INT NOT NULL,
    IdEmpleado INT NOT NULL,
    idTipoActividad INT NOT NULL,
    PRIMARY KEY (idActividadComplementaria)
);

-- Crear índice en la tabla DetalleActividad
CREATE INDEX IX_ActivityDetail ON DetalleActividad (idDetalleActividad);

-- Crear índice en la tabla TipoActividad
CREATE INDEX IX_ActivityType ON TipoActividad (idTipoActividad);

-- Crear índice en la tabla ActividadComplementaria
CREATE INDEX IX_ActividadComplementaria ON ActividadComplementaria (idActividadComplementaria);

-- Crear índice en la tabla Empleado
CREATE INDEX IX_Employee ON Empleado (idEmpleado);

-- Crear índice en la tabla DetalleEvaluacion
CREATE INDEX IX_DetalleEvaluacion ON DetalleEvaluacion (idDetalleEvaluacion);

-- Crear índice en la tabla Estudiante
CREATE INDEX IX_Estudiante ON Estudiante (idEstudiante);

ALTER TABLE ActividadComplementaria
ADD CONSTRAINT FK_ActividadComplementariaEstudiante
FOREIGN KEY (idEstudiante)
REFERENCES Estudiante (idEstudiante);
ALTER TABLE DetalleActividad
ADD CONSTRAINT FK_DetalleActividadDetalleEvaluacion
FOREIGN KEY (idDetalleEvaluacion)
REFERENCES DetalleEvaluacion (idDetalleEvaluacion);
ALTER TABLE DetalleActividad
ADD CONSTRAINT FK_ActivityDetailComplementaryActivity
FOREIGN KEY (idActividadComplementaria)
REFERENCES ActividadComplementaria (idActividadComplementaria);



INSERT INTO Empleado (nombre, apellidoPaterno, apellidoMaterno, genero, telefono, correo, direccion, seguroSocial, fechaContratacion)
VALUES
('Luis Alfonso', 'Rodriguez', 'Perez', 'Hombre', '8662567822', 'luis@gmail.com', 'Ayuntamiento 212 Occidental', '44180032044', '2023-01-23'),
('Alberto', 'Salazar', 'Zuñiga', 'Hombre', '8662347822', 'alberto@gmail.com', 'Ignacio allende 313 La sierrita', '44180032042', '2023-02-12'),
('Antonio', 'Rodriguez', 'Tovar', 'Hombre', '8661227822', 'antonio@gmail.com', 'Jalisco nte 1700 Monclova', '44180032043', '2023-02-10'),
('Gabriela', 'Mendoza', 'Aguilar', 'Mujer', '8662137822', 'gabriela@gmail.com', 'C. Monaco 1010 Monclova', '44180032044', '2023-04-11'),
('Patricia', 'Hernendez', 'Mata', 'Mujer', '8665437822', 'patricia@gmail.com', 'C. Zaragoza 227 Frontera', '44180032045', '2023-07-25');

INSERT INTO Estudiante (nombre, apellidoPaterno, apellidoMaterno, fechaNacimiento, curp, telefono, rfc, seguroSocial)
VALUES
('Nallely', 'Toledo', 'Alonso', '1996-06-09', 'TOASMNL000NLLN9654', '8667882323', 'TOASMNL000NLL', '44180032043'),
('Alberto', 'Salazar', 'Zuñiga', '2000-04-08', 'SAZA000408HCLLXLA6', '8661222321', 'SAZA000408K61', '44180032089'),
('Antonio', 'Perez', 'Gaitan', '2003-08-20', 'PEGA030820HCLLXKLR', '8664322321', 'PEGA030820HCL', '44180032090'),
('Maria', 'Rivera', 'Soledad', '2005-01-25', 'RISM000408HCLLXLA6', '8662332321', 'RISM000408HCL', '44180032011'),
('Bertha', 'Ibarra', 'Vazquez', '2007-09-17', 'VAVB000408HCLLXLO6', '8666542321', 'VAVB000408HCL', '44180032055');


INSERT INTO DetalleEvaluacion (calificacion, criterio)
VALUES
('9', 'Un buen desarrollo de trabajo'),
('10', 'Interesante trabajo solo la ortografia'),
('0', 'Ninguno'),
('0', 'Ninguno');

INSERT INTO TipoActividad (descripcion, nombreactividad)
VALUES
('practice', 'Proyecto de energías renovables la luz'),
('residence', 'Proyecto de Redes computacionales'),
('stay', 'Proyecto de Funcionamiento de automotriz'),
('socialservice', 'Proyecto de Diseñar una página web');


INSERT INTO ActividadComplementaria (nombreactividad, idEstudiante, idTipoActividad, IdEmpleado)
VALUES
('practice', 1, 1, 1),
('residence', 2, 2, 1),
('stay', 3, 3, 1),
('socialservice', 4, 4, 1);


INSERT INTO DetalleActividad (descripcion, idDetalleEvaluacion, idActividadComplementaria)
VALUES
('Ninguno', 1, 1),
('Interesante trabajo solo falta mejorar la ortografía', 2, 2),
('Ninguno', 3, 3),
('Ninguno', 4, 4);


update tipoactividad set nombreactividad ='practica'
where  idTipoActividad = 3;
select * from Estudiante;
select * from Empleado;
select * from TipoActividad;
select * from  ActividadComplementaria;
select * from DetalleEvaluacion;
select * from DetalleActividad;