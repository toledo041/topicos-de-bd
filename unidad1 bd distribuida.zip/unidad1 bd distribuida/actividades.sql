USE master;
GO
IF DB_ID (N'Actividades') IS NOT NULL
 DROP DATABASE Actividades;
GO
CREATE DATABASE	Actividades
ON
(NAME = Actividades,
    FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL16.TOLEDOSERVER\MSSQL\DATA\Actividades.mdf', 
    SIZE = 10,
    MAXSIZE = 50,
    FILEGROWTH = 5 )
LOG ON
(NAME =Actividades_log,
    FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL16.TOLEDOSERVER\MSSQL\DATA\Actividades.ldf',
    SIZE = 5MB,
    MAXSIZE = 25MB,
    FILEGROWTH = 5MB )
GO
USE Actividades;

GO	





CREATE TABLE TipoActividad (
idTipoActividad int IDENTITY(1,1),
descripcion varchar(100) NOT NULL,
nombreactividad varchar(100) NOT NULL,
estatus bit NOT NULL DEFAULT 1, 
CONSTRAINT PK_TipoActividad Primary KEY(idTipoActividad)
);

CREATE TABLE DetalleEvaluacion (
idDetalleEvaluacion int IDENTITY(1,1),
calificacion varchar(50) NOT NULL,
criterio varchar(100) NOT NULL,
estatus bit NOT NULL DEFAULT 1, 
CONSTRAINT PK_DetalleEvaluacion Primary KEY(idDetalleEvaluacion)
);
CREATE TABLE DetalleActividad (
idDetalleActividad int IDENTITY(1,1),
descripcion varchar(100) NOT NULL,
idDetalleEvaluacion int NULL,
idActividadComplementaria int NULL,
estatus bit NOT NULL DEFAULT 1, 
CONSTRAINT PK_DetalleActividad Primary KEY(idDetalleActividad)
);

CREATE TABLE Empleado (
idEmpleado int IDENTITY(1,1),
nombre varchar(50) NOT NULL,
apellidoPaterno varchar (50) NOT NULL,
apellidoMaterno varchar(50)NOT NULL,
genero varchar(50) NOT NULL,
telefono char(10) NOT NULL,
correo varchar(50) NOT NULL,
direccion varchar(100)NOT NULL, 
seguroSocial char(11)NOT NULL,
fechaContratacion date NOT NULL,
estatus bit NOT NULL DEFAULT 1,
CONSTRAINT PK_Empleado Primary KEY(idEmpleado)
);



 CREATE TABLE Estudiante
(   
	 idEstudiante int IDENTITY (1,1),
	 nombre varchar(50) NOT NULL,
	 apellidoPaterno varchar(50) NOT NULL,
	 apellidoMaterno varchar(50) NOT NULL,
	 fechaNacimiento date NOT NULL,
	 curp char (18 )NOT NULL,
	 telefono char (10 )NOT NULL,
	 rfc char (13 )NOT NULL,
	 seguroSocial char (11) NOT NULL,
	 estatus bit NOT NULL DEFAULT 1,
	 CONSTRAINT PK_Estudiante PRIMARY KEY (idEstudiante)
);




 CREATE TABLE ActividadComplementaria
(    
 idActividadComplementaria int IDENTITY (1,1), 
nombreactividad varchar(50) NOT NULL, 
 estatus bit NOT NULL DEFAULT 1, 
 idEstudiante int NOT NULL, 
 IdEmpleado int NOT NULL,
 idTipoActividad int NOT NULL,
 CONSTRAINT PK_ActividadComplementaria PRIMARY KEY (idActividadComplementaria) 
 );







---------------------Index----------------
CREATE INDEX IX_ActivityDetail ON DetalleActividad(idDetalleActividad)
CREATE INDEX IX_ActivityType ON TipoActividad(idTipoActividad)
CREATE INDEX IX_ActividadComplementaria ON ActividadComplementaria(idActividadComplementaria)
CREATE INDEX IX_Employee ON Empleado(idEmpleado)
CREATE INDEX IX_DetalleEvaluacion ON DetalleEvaluacion(idDetalleEvaluacion )
CREATE INDEX IX_Estudiante ON Estudiante  (idEstudiante )

-------------------Alter Table----------------------------
-------------------------------------------------------
ALTER TABLE ActividadComplementaria--- bien
ADD CONSTRAINT FK_ActividadComplementariaEstudiante FOREIGN KEY (idEstudiante)
REFERENCES Estudiante(idEstudiante)


ALTER TABLE DetalleActividad---bien
ADD CONSTRAINT FK_DettalleAcividadDetalleEvaluacion FOREIGN KEY (idDetalleEvaluacion)
REFERENCES DetalleEvaluacion (idDetalleEvaluacion)


ALTER TABLE DetalleActividad---bien
ADD CONSTRAINT FK_ActivityDetailComplementaryActivity FOREIGN KEY (idActividadComlementaria)
REFERENCES ActividadComplmentaria (idActividadComplementaria)



-----------------------poblacion-----------


INSERT INTO Empleado(nombre,apellidoPaterno,apellidoMaterno,genero,telefono,correo,direccion,seguroSocial,fechaContratacion)
VALUES ('bernardo','Rdz','soto','Hombre','8662567822','luis@gmail.com','Ayuntamiento 212 Occidental','44180032044','2023-01-23');
       ('Alberto','Salazar','Zu�iga','Hombre','8662347822','alberto@gmail.com','Ignacio allende 313 La sierrita','44180032042','2023-02-12'),
	   ('Antonio','Rodriguez','Tovar','Hombre','8661227822','antonio@gmail.com','Jalisco nte 1700 Monclova','44180032043','2023-02-10'),
	   ('Gabriela','Mendoza','Aguilar','Mujer','8662137822','gabriela@gmail.com','C. Monaco 1010 Monclova','44180032044','2023-04-11'),
	   ('Patricia','Hernendez','Mata','Mujer','8665437822','patricia@gmail.com','C. Zaragoza 227 Frontera','44180032045','2023-07-25');

INSERT INTO Estudiante(nombre,apellidoPaterno,apellidoMaterno,fechaNacimiento,curp,telefono,rfc,seguroSocial)
VALUES ('Nallely','Toledo','Alonso','1996-06-09','TOASMNL000NLLN9654','8667882323','TOASMNL000NLL','44180032043'),
       ('Alberto','Salazar','Zu�iga','2000-04-08','SAZA000408HCLLXLA6','8661222321','SAZA000408K61','44180032089'),
	   ('Antonio','Perez','Gaitan','2003-08-20','PEGA030820HCLLXKLR','8664322321','PEGA030820HCL','44180032090'),
	   ('Maria','Rivera','Soledad','2005-01-25','RISM000408HCLLXLA6','8662332321','RISM000408HCL','44180032011'),
	   ('Bertha','Ibarra','Vazquez','2007-09-17','VAVB000408HCLLXLO6','8666542321','VAVB000408HCL','44180032055');
	   

	   INSERT INTO DetalleEvaluacion(calificacion,criterio)
VALUES('9','Un buen desarrollo de trabajo'),
      ('10','Interesante trabajo solo la ortografia'),
	  ('0','Ninguno'),
      ('0','Ninguno');

	 
INSERt INTO TipoActividad(descripcion,nombreactividad)
VALUES('practice','Proyecto de energias renovables la luz'),
      ('residence ','Proyecto de Redes computacionales'),
	  ('stay','Proyecto de Funcionamiento de automotriz'),
      ('socialservice','Proyecto de Dise�ar una pagina web');

INSERt INTO ActividadComplementaria(nombreactividad,idEstudiante,idTipoActividad,IdEmpleado)
VALUES('practice',1,1,1),
      ('residence ',2,2,1),
	  (' stay',3,3,1),
      ('socialservice',4,4,1);

 INSERt INTO DetalleActividad(descripcion,idDetalleEvaluacion,idActividadComplementaria)
VALUES('Ninguno',1,1),
      ('Interesante trabajo solo falta menjorar la ortografia ',2,2),
	  ('Ninguno',3,3),
      ('Ninguno',4,4);
Select * from DetalleActividad
Select * from TipoActividad
Select * from DetalleEvaluacion
Select * from Empleado
Select * from Estudiante
Select * from ActividadComplementaria

------select para bd mysql 
select *from mysql_actividades...tipoactividad
select * from mysql_actividades...Estudiante
select * from mysql_actividades...Empleado;
select * from mysql_actividades...TipoActividad
select * from  mysql_actividades...ActividadComplementaria
select * from mysql_actividades...DetalleEvaluacion
select * from mysql_actividades...DetalleActividad

-----eliminar


delete from mysql...empledo where idEmpleado= 6

---insertar
insert into mysql_actividades...TipoActividad(descripcion,nombreactividad)
VALUES('intercambio','Proyecto de energias renovables');


-----------------crear vista
create view v_empleados_bd_distribuida
as
select * from Empleado
union all
select *from mysql_actividades...empleado;

------------ver vista
select * from dbo.v_empleados_bd_distribuida
